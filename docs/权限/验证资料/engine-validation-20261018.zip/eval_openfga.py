import json,urllib.request,urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parent
state=json.loads((ROOT/'containers.json').read_text())
base=state['openfga']['url']
history=[]
def req(path,body):
    r=urllib.request.Request(base+path,json.dumps(body).encode(),{'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(r,timeout=12) as response:code=response.status;value=json.load(response)
    except urllib.error.HTTPError as e:code=e.code;value=json.load(e)
    history.append({'path':path,'request':body,'status':code,'response':value})
    if code>=300:raise RuntimeError(json.dumps(history[-1]))
    return value
store=req('/stores',{'name':'ontology-isolated-evaluation'})['id']
this={'this':{}}
def comp(r):return {'computedUserset':{'relation':r}}
def through(r,c):return {'tupleToUserset':{'tupleset':{'relation':r},'computedUserset':{'relation':c}}}
def intersect(*args):return {'intersection':{'child':list(args)}}
def union(*args):return {'union':{'child':list(args)}}
def minus(base,sub):return {'difference':{'base':base,'subtract':sub}}
def direct(t,relation=None,condition=None):
    x={'type':t}
    if relation:x['relation']=relation
    if condition:x['condition']=condition
    return x
types=[
 {'type':'user'},
 {'type':'group','relations':{'member':this},'metadata':{'relations':{'member':{'directly_related_user_types':[direct('user')]}}}},
 {'type':'tenant','relations':{'member':this},'metadata':{'relations':{'member':{'directly_related_user_types':[direct('user'),direct('group','member')]}}}},
 {'type':'department','relations':{'member':this,'finance':this},'metadata':{'relations':{r:{'directly_related_user_types':[direct('user'),direct('group','member')]} for r in ['member','finance']}}},
]
relations={r:this for r in ['tenant','department','viewer','blocked','price_denied','action_grant','function_grant']}
relations.update({
 'read':minus(intersect(through('tenant','member'),union(comp('viewer'),through('department','member'))),comp('blocked')),
 'read_price':minus(intersect(through('tenant','member'),through('department','finance')),union(comp('blocked'),comp('price_denied'))),
 'action_invoke':minus(intersect(through('tenant','member'),comp('action_grant')),comp('blocked')),
 'function_invoke':minus(intersect(through('tenant','member'),comp('function_grant')),comp('blocked')),
})
metadata={r:{'directly_related_user_types':ts} for r,ts in {
 'tenant':[direct('tenant')],'department':[direct('department')],
 'viewer':[direct('user'),direct('group','member')],
 'blocked':[direct('user')],'price_denied':[direct('user')],
 'action_grant':[direct('user',condition='valid_action')],
 'function_grant':[direct('user',condition='valid_chain')],
}.items()}
types.append({'type':'equipment','relations':relations,'metadata':{'relations':metadata}})
model={'schema_version':'1.1','type_definitions':types,'conditions':{
 'valid_action':{'name':'valid_action','expression':'reason in ["repair", "inspect"] && caller_department == resource_department','parameters':{x:{'type_name':'TYPE_NAME_STRING'} for x in ['reason','caller_department','resource_department']}},
 'valid_chain':{'name':'valid_chain','expression':'via_action == "maintenance"','parameters':{'via_action':{'type_name':'TYPE_NAME_STRING'}}},
}}
model_id=req(f'/stores/{store}/authorization-models',model)['authorization_model_id']
tuples=[]
def tup(user,relation,obj,condition=None):
    t={'user':user,'relation':relation,'object':obj}
    if condition:t['condition']=condition
    tuples.append(t)
tup('user:alice','member','tenant:t1')
tup('user:alice','member','group:catalog')
tup('user:alice','member','department:d1')
tup('user:alice','finance','department:d1')
suite=json.loads((ROOT/'cases.json').read_text())
for row in suite['rows']:
    obj='equipment:'+row['id']
    tup('tenant:'+row['tenant'],'tenant',obj)
    tup('group:catalog#member','viewer',obj)
    if row['department']:tup('department:'+row['department'],'department',obj)
    if row['blocked']:tup('user:alice','blocked',obj)
    if row['department']=='d1' and row['line']=='l1':
        tup('user:alice','action_grant',obj,{'name':'valid_action','context':{'resource_department':row['department']}})
        tup('user:alice','function_grant',obj,{'name':'valid_chain'})
req(f'/stores/{store}/write',{'authorization_model_id':model_id,'writes':{'tuple_keys':tuples}})
cases=[]
def check(name,relation,obj,expected,context=None):
    body={'authorization_model_id':model_id,'tuple_key':{'user':'user:alice','relation':relation,'object':'equipment:'+obj},'consistency':'HIGHER_CONSISTENCY'}
    if context:body['context']=context
    raw=req(f'/stores/{store}/check',body)
    cases.append({'name':name,'expected':expected,'allowed':raw['allowed'],'pass':raw['allowed']==expected})
check('read-own','read','e1',True)
check('read-other-department-catalog','read','e2',True)
check('price-own','read_price','e1',True)
check('price-other-department','read_price','e2',False)
check('cross-tenant','read','e4',False)
check('blocked','read','e5',False)
check('price-null-department','read_price','e6',False)
check('action-parameter','action_invoke','e1',True,{'reason':'repair','caller_department':'d1'})
check('action-bad-parameter','action_invoke','e1',False,{'reason':'delete_all','caller_department':'d1'})
check('function-direct','function_invoke','e1',False,{'via_action':''})
check('function-via-action','function_invoke','e1',True,{'via_action':'maintenance'})
lists={}
for relation in ['read','read_price']:
    result=req(f'/stores/{store}/list-objects',{'authorization_model_id':model_id,'type':'equipment','relation':relation,'user':'user:alice','consistency':'HIGHER_CONSISTENCY'})
    actual=sorted(result['objects']);expected=['equipment:'+x for x in (['e1','e2','e3','e6'] if relation=='read' else ['e1','e3'])]
    lists[relation]={'objects':actual,'expected':expected,'pass':actual==expected,'keys':list(result)}
req(f'/stores/{store}/write',{'authorization_model_id':model_id,'writes':{'tuple_keys':[{'user':'user:alice','relation':'price_denied','object':'equipment:e1'}]}})
check('explicit-field-deny','read_price','e1',False)
req(f'/stores/{store}/write',{'authorization_model_id':model_id,'deletes':{'tuple_keys':[{'user':'user:alice','relation':'member','object':'tenant:t1'}]}})
check('tenant-membership-revoked','read','e1',False)
out={'engine':'OpenFGA v1.22.0','model_id':model_id,'cases':cases,'lists':lists,'tuple_count':len(tuples),'history':history}
(ROOT/'evidence/openfga-checks.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'engine':out['engine'],'passed':sum(x['pass'] for x in cases),'cases':len(cases),'lists':lists},indent=2))
