import json,urllib.request,urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parent
state=json.loads((ROOT/'containers.json').read_text());base=state['spicedb']['url'];history=[]
def req(path,body):
    r=urllib.request.Request(base+path,json.dumps(body).encode(),{'Content-Type':'application/json','Authorization':'Bearer ontology-temporary-evaluation'})
    try:
        with urllib.request.urlopen(r,timeout=12) as response:
            code=response.status;raw=response.read().decode()
            try:value=json.loads(raw)
            except ValueError:value=[json.loads(x) for x in raw.splitlines() if x.strip()]
    except urllib.error.HTTPError as e:code=e.code;value=json.load(e)
    history.append({'path':path,'request':body,'status':code,'response':value})
    if code>=300:raise RuntimeError(json.dumps(history[-1]))
    return value
schema='''definition user {}
definition group {
  relation member: user
}
definition tenant {
  relation member: user | group#member
}
definition department {
  relation member: user | group#member
  relation finance: user | group#member
}
caveat valid_action(reason string, caller_department string, resource_department string) {
  reason in ["repair", "inspect"] && caller_department == resource_department
}
caveat valid_chain(via_action string) {
  via_action == "maintenance"
}
definition equipment {
  relation tenant: tenant
  relation department: department
  relation viewer: user | group#member
  relation blocked: user
  relation price_denied: user
  relation action_grant: user with valid_action
  relation function_grant: user with valid_chain
  permission read = ((tenant->member) & (viewer + department->member)) - blocked
  permission read_price = ((tenant->member) & (department->finance)) - (blocked + price_denied)
  permission action_invoke = ((tenant->member) & action_grant) - blocked
  permission function_invoke = ((tenant->member) & function_grant) - blocked
}
'''
req('/v1/schema/write',{'schema':schema})
updates=[]
def relationship(user,relation,obj,caveat=None):
    ot,oid=obj.split(':');st,sid=user.split(':');subject={'object':{'objectType':st,'objectId':sid.split('#')[0]}}
    if '#' in sid:subject['optionalRelation']=sid.split('#')[1]
    r={'resource':{'objectType':ot,'objectId':oid},'relation':relation,'subject':subject}
    if caveat:r['optionalCaveat']=caveat
    return r
def tup(user,relation,obj,caveat=None):updates.append({'operation':'OPERATION_CREATE','relationship':relationship(user,relation,obj,caveat)})
tup('user:alice','member','tenant:t1')
tup('user:alice','member','group:catalog')
tup('user:alice','member','department:d1')
tup('user:alice','finance','department:d1')
suite=json.loads((ROOT/'cases.json').read_text())
for row in suite['rows']:
    obj='equipment:'+row['id'];tup('tenant:'+row['tenant'],'tenant',obj);tup('group:catalog#member','viewer',obj)
    if row['department']:tup('department:'+row['department'],'department',obj)
    if row['blocked']:tup('user:alice','blocked',obj)
    if row['department']=='d1' and row['line']=='l1':
        tup('user:alice','action_grant',obj,{'caveatName':'valid_action','context':{'resource_department':row['department']}})
        tup('user:alice','function_grant',obj,{'caveatName':'valid_chain'})
req('/v1/relationships/write',{'updates':updates})
cases=[]
def check(name,permission,obj,expected,context=None):
    body={'resource':{'objectType':'equipment','objectId':obj},'permission':permission,'subject':{'object':{'objectType':'user','objectId':'alice'}},'consistency':{'fullyConsistent':True}}
    if context is not None:body['context']=context
    raw=req('/v1/permissions/check',body);allowed=raw['permissionship']=='PERMISSIONSHIP_HAS_PERMISSION'
    cases.append({'name':name,'expected':expected,'allowed':allowed,'pass':allowed==expected})
check('read-own','read','e1',True)
check('read-other-department-catalog','read','e2',True)
check('price-own','read_price','e1',True)
check('price-other-department','read_price','e2',False)
check('cross-tenant','read','e4',False)
check('blocked','read','e5',False)
check('price-null-department','read_price','e6',False)
check('action-parameter','action_invoke','e1',True,{'reason':'repair','caller_department':'d1'})
check('action-bad-parameter','action_invoke','e1',False,{'reason':'delete_all','caller_department':'d1'})
check('function-direct','function_invoke','e1',False,{'via_action':''})
check('function-via-action','function_invoke','e1',True,{'via_action':'maintenance'})
lists={}
for relation in ['read','read_price']:
    result=req('/v1/permissions/resources',{'resourceObjectType':'equipment','permission':relation,'subject':{'object':{'objectType':'user','objectId':'alice'}},'consistency':{'fullyConsistent':True}})
    if isinstance(result,dict):result=[result]
    actual=sorted(x['result']['resourceObjectId'] for x in result);expected=['e1','e2','e3','e6'] if relation=='read' else ['e1','e3']
    lists[relation]={'objects':actual,'expected':expected,'pass':actual==expected}
req('/v1/relationships/write',{'updates':[{'operation':'OPERATION_CREATE','relationship':relationship('user:alice','price_denied','equipment:e1')}]})
check('explicit-field-deny','read_price','e1',False)
req('/v1/relationships/write',{'updates':[{'operation':'OPERATION_DELETE','relationship':relationship('user:alice','member','tenant:t1')}]})
check('tenant-membership-revoked','read','e1',False)
out={'engine':'SpiceDB v1.56.2','cases':cases,'lists':lists,'relationship_count':len(updates),'history':history}
(ROOT/'evidence/spicedb-checks.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'engine':out['engine'],'passed':sum(x['pass'] for x in cases),'cases':len(cases),'lists':lists},indent=2))
