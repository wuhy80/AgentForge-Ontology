from pathlib import Path
import json,urllib.request,urllib.error,sqlite3,sys
ROOT=Path(__file__).resolve().parent
suite=json.loads((ROOT/'cases.json').read_text())
state=json.loads((ROOT/'containers.json').read_text())
def req(base,path,body=None,headers=None,method=None):
    if isinstance(body,str):payload=body.encode()
    else:payload=json.dumps(body).encode() if body is not None else None
    r=urllib.request.Request(base+path,payload,headers={'Content-Type':'application/json',**(headers or {})},method=method)
    try:
        with urllib.request.urlopen(r,timeout=15) as f:
            raw=f.read().decode();return f.status,json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        return e.code,json.loads(e.read())

db=sqlite3.connect(':memory:')
db.execute('CREATE TABLE equipment (id TEXT,tenant TEXT,department TEXT,line TEXT,blocked BOOLEAN,status TEXT,price NUMERIC)')
for row in suite['rows']:db.execute('INSERT INTO equipment VALUES (?,?,?,?,?,?,?)',tuple(row[k] for k in ['id','tenant','department','line','blocked','status','price']))
fieldnames={'tenant','department','line','blocked','status','price','id'}
def ucast(node):
    params=[]
    if node.get('type')=='compound':
        children=[ucast(x) for x in node['value']]
        if node['operator'] in ['and','or']:
            return '('+(' AND ' if node['operator']=='and' else ' OR ').join(x[0] for x in children)+')',[v for x in children for v in x[1]]
        if node['operator']=='not':return '(NOT '+children[0][0]+')',children[0][1]
        raise ValueError(node)
    if node.get('type')=='field':
        field=node['field'].removeprefix('resource.')
        if field not in fieldnames:raise ValueError(node)
        name='"'+field+'"';op=node['operator'];value=node.get('value')
        if op=='eq':return name+' IS ?', [value]
        if op=='ne':return name+' IS NOT ?', [value]
        if op=='in':
            if not value:return '0',[]
            return name+' IN ('+','.join('?' for _ in value)+')',value
        raise ValueError(node)
    raise ValueError(node)
def cerbos(node):
    if 'variable' in node:
        field=node['variable'].removeprefix('request.resource.attr.')
        if field not in fieldnames:raise ValueError(node)
        return '"'+field+'"',[]
    if 'value' in node:return '?',[node['value']]
    exp=node['expression'];op=exp['operator'];parts=[cerbos(x) for x in exp['operands']]
    if op in ['and','or']:return '('+(' AND ' if op=='and' else ' OR ').join(x[0] for x in parts)+')',[v for x in parts for v in x[1]]
    if op=='not':return '(NOT '+parts[0][0]+')',parts[0][1]
    if op in ['eq','ne']:return '('+parts[0][0]+(' IS ' if op=='eq' else ' IS NOT ')+parts[1][0]+')',parts[0][1]+parts[1][1]
    if op=='in':
        values=parts[1][1][0]
        if not values:return '0',[]
        return parts[0][0]+' IN ('+','.join('?' for _ in values)+')',parts[0][1]+values
    raise ValueError(node)

for engine in sys.argv[1:]:
    base=state[engine]['url'];plans=[]
    core=json.loads((ROOT/'evidence'/(engine+'-checks.json')).read_text())
    for tc in suite['cases']:
        i={**tc['input']};i.pop('resource')
        if engine=='opa':
            code,raw=req(base,'/v1/compile/ontology/allow',{'input':i,'unknowns':['input.resource']},{'Accept':'application/vnd.opa.ucast.all+json'})
            query=raw.get('result',{}).get('query',None)
            if query is None:sql,params='0',[]
            elif query=={}:sql,params='1',[]
            else:sql,params=ucast(query)
        else:
            s=i['subject'];principal={'id':s['id'],'roles':s['roles'] or ['__authenticated'],'attr':{k:v for k,v in s.items() if k not in ['id','roles']}}
            body={'principal':principal,'resource':{'kind':'equipment','attr':{k:v for k,v in i.items() if k not in ['subject','operation']}},'actions':[i['operation']]}
            code,raw=req(base,'/api/plan/resources',body)
            f=raw.get('filter',{})
            if f.get('kind')=='KIND_ALWAYS_DENIED':sql,params='0',[]
            elif f.get('kind')=='KIND_ALWAYS_ALLOWED':sql,params='1',[]
            else:sql,params=cerbos(f['condition'])
        actual=[x[0] for x in db.execute('SELECT id FROM equipment WHERE '+sql,params)]
        expected=[]
        for row in suite['rows']:
            full={**i,'resource':row}
            if engine=='opa':c,r=req(base,'/v1/data/ontology/allow',{'input':full});allow=r.get('result',False)
            else:
                attr={**row,**{k:v for k,v in i.items() if k not in ['subject','operation']}}
                c,r=req(base,'/api/check/resources',{'principal':principal,'resources':[{'resource':{'id':row['id'],'kind':'equipment','attr':attr},'actions':[i['operation']]}]})
                allow=r.get('results',[{}])[0].get('actions',{}).get(i['operation'])=='EFFECT_ALLOW'
            if c!=200:raise ValueError(r)
            if allow:expected.append(row['id'])
        plans.append({'name':tc['name'],'status':code,'pass':code==200 and actual==expected,'selected':actual,'expected_from_checks':expected,'sql':sql,'parameters':params,'engine_response':raw})
    out={'engine':engine,'backend':'SQLite in-memory, temporary allowlisted parameterized AST adapter','plans':plans,'comparisons':len(plans)*len(suite['rows'])}
    (ROOT/'evidence'/(engine+'-plan-equivalence.json')).write_text(json.dumps(out,indent=2))
    print(json.dumps({'engine':engine,'passed':sum(x['pass'] for x in plans),'plans':len(plans),'resource_comparisons':out['comparisons'],'failed':[x for x in plans if not x['pass']]},indent=2))
