# Ontology permission-engine evaluation, 2026-10-18

This archive contains temporary experiment fixtures and captured responses. It is outside the business repository. It does not implement Ontology, certify database compatibility, benchmark production performance, or prove multi-replica revocation.

The selection is OPA 1.21.2. Read `evidence/summary.json` and `evidence/manifest.json` first, then the request/response files. All subjects and business objects are synthetic. The SpiceDB preshared key in the fixture is an isolated experiment key, not a production credential. Containers use memory stores where applicable and bind only to 127.0.0.1.

Versions:

- OPA 1.21.2, `openpolicyagent/opa:1.21.2-static`
- Cerbos 0.56.0, `ghcr.io/cerbos/cerbos:0.56.0`
- Casbin 3.11.0, Go module `github.com/casbin/casbin/v3`
- OpenFGA 1.22.0, `openfga/openfga:v1.22.0`
- SpiceDB 1.56.2, `ghcr.io/authzed/spicedb:v1.56.2`

The scripts use Python 3.12 standard-library modules and the local Docker CLI. Casbin was run using Go 1.22.1. The Docker executable path in `start_engines.py` is specific to this workstation and may need adjustment. Pull the pinned images before starting. Network download delays are not engine-performance results.

To reproduce the corrected policies, unpack the archive outside a business repository. Keep `cases.json`, `ontology.rego`, `policies/equipment.yaml`, and `cerbos.yaml` as provided. Do not run `setup_lab.py`: it regenerates the initial Cerbos policy before the cross-role deny adjustment, and is included to explain that observation.

Run the following from the unpacked directory, waiting for the engines to finish startup before invoking the evaluation scripts:

```text
python start_engines.py opa cerbos openfga spicedb
python eval_core.py opa cerbos
python eval_plans.py opa cerbos
python eval_opa_extra.py
python eval_openfga.py
python eval_spicedb.py
go -C casbin mod download
go -C casbin run .
```

The scripts produce `containers.json` for the new run. The archive intentionally excludes the live `containers.json`; observed container identities and digests are kept only in the evidence manifest. Repeated relation-engine scripts mutate their own in-memory experiment data. Restarting a container may allocate a different host port, so update its recorded URL from `docker inspect` before reusing it.

`eval_plans.py` creates only an in-memory SQLite table, compiles allowlisted engine condition nodes into parameterized SQL, and compares the selected rows against per-object checks. It does not execute the engine's MySQL/PostgreSQL SQL text. It validates 24 plans against 6 objects per engine, including NULL data. Its temporary adapter is intentionally limited to the fixture operators and is not a production compiler.

Cerbos initially allowed a user with both finance allow and contractor deny roles, consistent with its documented role-union semantics. The provided corrected policy includes a contractor exclusion in the finance price rule. The original response is retained in `evidence/cerbos-initial-checks.json`. An empty roles array was rejected by the Cerbos API; the corrected experiment maps it to an authenticated role with no grants.

Casbin's captured supported condition-extraction example includes both an allow predicate and a deny predicate. Per-object Enforce still denies correctly. This is a limitation of interpreting the extracted strings as a complete collection filter, not a claim that Casbin's Enforce is incorrect.

OPA extras capture static mask compilation, data-state changes on one instance, unsupported filter builtin/dialect errors, and a missing-subject-attribute denial. The MySQL escaping result is recorded as an observation, not a tested SQL injection finding or a database certification. UCAST preserves the input as a value; applications must compile parameters and authenticate their context.

Clean up only the containers identified by the new run's `containers.json` and carrying the `ontology.auth-eval=true` label. Downloaded images may remain cached. The original experiment containers were removed after evidence collection.
