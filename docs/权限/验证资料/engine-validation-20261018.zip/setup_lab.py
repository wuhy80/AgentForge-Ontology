from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
(ROOT / 'policies').mkdir(exist_ok=True)

principal = {'id': 'alice', 'tenant': 't1', 'department': 'd1', 'lines': ['l1'], 'roles': ['catalog', 'maintainer', 'finance']}
rows = [
    {'id': 'e1', 'tenant': 't1', 'department': 'd1', 'line': 'l1', 'blocked': False, 'status': 'stopped', 'price': 100},
    {'id': 'e2', 'tenant': 't1', 'department': 'd2', 'line': 'l2', 'blocked': False, 'status': 'stopped', 'price': 200},
    {'id': 'e3', 'tenant': 't1', 'department': 'd1', 'line': 'l2', 'blocked': False, 'status': 'stopped', 'price': 300},
    {'id': 'e4', 'tenant': 't2', 'department': 'd1', 'line': 'l1', 'blocked': False, 'status': 'stopped', 'price': 400},
    {'id': 'e5', 'tenant': 't1', 'department': 'd1', 'line': 'l1', 'blocked': True, 'status': 'stopped', 'price': 500},
    {'id': 'e6', 'tenant': 't1', 'department': None, 'line': 'l1', 'blocked': False, 'status': 'stopped', 'price': 600},
]
cases = []
def case(name, operation, row, expected, roles=None, **extra):
    s = dict(principal)
    if roles is not None: s['roles'] = roles
    cases.append({'name': name, 'input': {'subject': s, 'resource': dict(rows[row]), 'operation': operation, **extra}, 'expected': expected})

case('read-own', 'read', 0, True)
case('read-other-department-catalog', 'read', 1, True)
case('read-price-own', 'read_price', 0, True)
case('read-price-other-department', 'read_price', 1, False)
case('read-price-same-department-other-line', 'read_price', 2, True)
case('cross-tenant', 'read', 3, False)
case('explicit-block', 'read', 4, False)
case('contractor-deny-price', 'read_price', 0, False, roles=['finance', 'contractor'])
case('no-role-default-deny', 'read', 0, False, roles=[])
case('action-own', 'action_invoke', 0, True, reason='repair')
case('action-other-department', 'action_invoke', 1, False, reason='repair')
case('action-other-line', 'action_invoke', 2, False, reason='repair')
case('action-bad-parameter', 'action_invoke', 0, False, reason='delete_all')
case('function-direct-deny', 'function_invoke', 0, False, via_action='')
case('function-via-action', 'function_invoke', 0, True, via_action='maintenance')
case('function-via-wrong-action', 'function_invoke', 0, False, via_action='other')
case('patch-old-new', 'patch_status', 0, True, new_department='d1', new_status='running')
case('patch-department-transfer', 'patch_status', 0, False, new_department='d2', new_status='running')
case('patch-invalid-new-status', 'patch_status', 0, False, new_department='d1', new_status='deleted')
case('price-null-department', 'read_price', 5, False)
case('read-null-department-catalog', 'read', 5, True)
case('unknown-operation', 'superadmin', 0, False)
case('membership-revoked', 'action_invoke', 0, False, roles=['catalog'], reason='repair')
case('contractor-readable-name', 'read_name', 0, True, roles=['catalog', 'contractor'])
(ROOT/'cases.json').write_text(json.dumps({'principal': principal, 'rows': rows, 'cases': cases}, indent=2), encoding='utf-8')

valid = 'request.resource.attr.tenant == request.principal.attr.tenant && request.resource.attr.blocked == false'
own = 'request.resource.attr.department == request.principal.attr.department && request.resource.attr.line in request.principal.attr.lines'
department = 'request.resource.attr.department == request.principal.attr.department'
rules = []
def rule(actions, roles, expression, effect='EFFECT_ALLOW'):
    rules.append({'actions': actions, 'roles': roles, 'effect': effect, 'condition': {'match': {'expr': expression}}})
rule(['read', 'read_name'], ['catalog'], valid)
rule(['read', 'read_name'], ['maintainer'], f'({valid}) && ({own})')
rule(['read', 'read_name', 'read_price'], ['finance'], f'({valid}) && ({department})')
rule(['read_price'], ['contractor'], 'true', 'EFFECT_DENY')
rule(['*'], ['*'], 'request.resource.attr.blocked == true', 'EFFECT_DENY')
rule(['action_invoke'], ['maintainer'], f'({valid}) && ({own}) && request.resource.attr.reason in ["repair", "inspect"]')
rule(['function_invoke'], ['maintainer'], f'({valid}) && ({own}) && request.resource.attr.via_action == "maintenance"')
rule(['patch_status'], ['maintainer'], f'({valid}) && ({own}) && request.resource.attr.status == "stopped" && request.resource.attr.new_status == "running" && request.resource.attr.new_department == request.principal.attr.department')
policy = {'apiVersion': 'api.cerbos.dev/v1', 'resourcePolicy': {'version': 'default', 'resource': 'equipment', 'rules': rules}}
(ROOT/'policies'/'equipment.yaml').write_text(json.dumps(policy, indent=2), encoding='utf-8')
config = {'server': {'httpListenAddr': ':3592', 'grpcListenAddr': ':3593'}, 'storage': {'driver': 'disk', 'disk': {'directory': '/policies', 'watchForChanges': False}}, 'telemetry': {'disabled': True}}
(ROOT/'cerbos.yaml').write_text(json.dumps(config, indent=2), encoding='utf-8')
print(json.dumps({'root': str(ROOT), 'cases': len(cases), 'rows': len(rows)}))
