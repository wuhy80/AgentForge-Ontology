package main

import (
    "encoding/json"
    "fmt"
    "os"
    "strings"
    "time"

    "github.com/casbin/casbin/v3"
    "github.com/casbin/casbin/v3/model"
)

type Subject struct { Tenant string `json:"tenant"`; Department string `json:"department"`; Lines []string `json:"lines"`; Roles []string `json:"roles"` }
type Resource struct { ID string `json:"id"`; Tenant string `json:"tenant"`; Department *string `json:"department"`; Line string `json:"line"`; Blocked bool `json:"blocked"`; Status string `json:"status"` }
type Input struct { Subject Subject `json:"subject"`; Resource Resource `json:"resource"`; Operation string `json:"operation"`; Reason string `json:"reason"`; ViaAction string `json:"via_action"`; NewDepartment string `json:"new_department"`; NewStatus string `json:"new_status"` }
type Case struct { Name string `json:"name"`; Input Input `json:"input"`; Expected bool `json:"expected"` }
func has(roles []string, role string) bool { for _, r := range roles { if r == role { return true } }; return false }

func main() {
    data, err := os.ReadFile("../cases.json"); if err != nil { panic(err) }
    var suite struct { Cases []Case `json:"cases"` }; if err=json.Unmarshal(data, &suite); err!=nil { panic(err) }
    const conf = `[request_definition]
r = sub, obj, act, ctx
[policy_definition]
p = role, act, cond, eft
[policy_effect]
e = some(where (p.eft == allow)) && !some(where (p.eft == deny))
[matchers]
m = hasRole(r.sub.Roles, p.role) && (p.act == "*" || r.act == p.act) && eval(p.cond)
`
    m,err:=model.NewModelFromString(conf);if err!=nil {panic(err)}
    e,err:=casbin.NewEnforcer(m);if err!=nil {panic(err)}
    e.AddFunction("hasRole",func(args ...interface{})(interface{},error){ role:=args[1].(string);return role=="*" || has(args[0].([]string),role),nil })
    e.AddFunction("sameDept",func(args ...interface{})(interface{},error){ d:=args[1].(*string);return d!=nil && args[0].(string)==*d,nil })
    e.AddFunction("inLines",func(args ...interface{})(interface{},error){return has(args[1].([]string),args[0].(string)),nil})
    valid:=`r.sub.Tenant == r.obj.Tenant && r.obj.Blocked == false`
    own:=`sameDept(r.sub.Department, r.obj.Department) && inLines(r.obj.Line, r.sub.Lines)`
    add:=func(role,act,cond,eft string){if _,err:=e.AddPolicy(role,act,cond,eft);err!=nil{panic(err)}}
    for _,act:=range []string{"read","read_name"} {
        add("catalog",act,valid,"allow")
        add("finance",act,valid+` && sameDept(r.sub.Department, r.obj.Department)`,"allow")
        add("maintainer",act,valid+` && `+own,"allow")
    }
    add("finance","read_price",valid+` && sameDept(r.sub.Department, r.obj.Department)`,"allow")
    add("contractor","read_price","true","deny")
    add("*","*","r.obj.Blocked == true","deny")
    add("maintainer","action_invoke",valid+` && `+own+` && (r.ctx.Reason == "repair" || r.ctx.Reason == "inspect")`,"allow")
    add("maintainer","function_invoke",valid+` && `+own+` && r.ctx.ViaAction == "maintenance"`,"allow")
    add("maintainer","patch_status",valid+` && `+own+` && r.obj.Status == "stopped" && r.ctx.NewStatus == "running" && r.ctx.NewDepartment == r.sub.Department`,"allow")
    var results []map[string]interface{}
    for _,tc:=range suite.Cases { allowed,err:=e.Enforce(tc.Input.Subject,tc.Input.Resource,tc.Input.Operation,tc.Input); r:=map[string]interface{}{"name":tc.Name,"allowed":allowed,"expected":tc.Expected,"pass":err==nil&&allowed==tc.Expected};if err!=nil{r["error"]=err.Error()};results=append(results,r) }
    started:=time.Now();for i:=0;i<1000;i++ {tc:=suite.Cases[i%len(suite.Cases)];_,err:=e.Enforce(tc.Input.Subject,tc.Input.Resource,tc.Input.Operation,tc.Input);if err!=nil{panic(err)}}
    // The condition API expects a fixed p={sub,obj,act} model; it is not a general ABAC-to-query compiler.
    _,conditionErr:=e.GetAllowedObjectConditions("alice","read","r.obj.")
    const conditionModel = `[request_definition]
r = sub, obj, act
[policy_definition]
p = sub, obj, act, eft
[role_definition]
g = _, _
[policy_effect]
e = some(where (p.eft == allow)) && !some(where (p.eft == deny))
[matchers]
m = g(r.sub, p.sub) && eval(p.obj) && r.act == p.act
`
    cm,err:=model.NewModelFromString(conditionModel);if err!=nil{panic(err)}
    ce,err:=casbin.NewEnforcer(cm);if err!=nil{panic(err)}
    ce.AddPolicy("finance",`r.obj.Department == "d1"`,"read","allow")
    ce.AddPolicy("banned",`r.obj.Blocked == true`,"read","deny")
    ce.AddGroupingPolicy("alice","finance");ce.AddGroupingPolicy("alice","banned")
    extracted,extractErr:=ce.GetAllowedObjectConditions("alice","read","r.obj.")
    denied,err:=ce.Enforce("alice",struct{Department string;Blocked bool}{"d1",true},"read");if err!=nil{panic(err)}
    conditionExample:=map[string]interface{}{"conditions":extracted,"error":fmt.Sprint(extractErr),"blocked_row_enforce":denied,"contains_deny_predicate":has(extracted,`Blocked == true`)}
    out:=map[string]interface{}{"engine":"Casbin v3.11.0","cases":results,"warm_1000_inprocess_ms":float64(time.Since(started).Microseconds())/1000,"query_condition_error":fmt.Sprint(conditionErr),"supported_condition_api_example":conditionExample,"policy_count":len(e.GetModel()["p"]["p"].Policy),"notes":strings.Join([]string{"custom ABAC helpers","condition extraction needs model-specific allow/deny interpretation"},"; ")}
    enc:=json.NewEncoder(os.Stdout);enc.SetIndent("","  ");if err:=enc.Encode(out);err!=nil{panic(err)}
}
