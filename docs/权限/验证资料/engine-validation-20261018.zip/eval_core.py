from pathlib import Path
import json,urllib.request,urllib.error,sys,time
ROOT=Path(__file__).resolve().parent
suite=json.loads((ROOT/'cases.json').read_text())
state=json.loads((ROOT/'containers.json').read_text())
def request(url,body=None,headers=None,method=None):
    payload=json.dumps(body).encode() if body is not None else None
    req=urllib.request.Request(url,payload,headers={'Content-Type':'application/json',**(headers or {})},method=method)
    try:
        with urllib.request.urlopen(req,timeout=12) as r:
            data=r.read().decode();return r.status,json.loads(data) if data else {}
    except urllib.error.HTTPError as e:
        raw=e.read().decode()
        try:return e.code,json.loads(raw)
        except ValueError:return e.code,{'raw':raw}

def principal(subject):
    return {'id':subject['id'],'roles':subject['roles'] or ['__authenticated'],'attr':{k:v for k,v in subject.items() if k not in ['id','roles']}}

for engine in sys.argv[1:]:
    base=state[engine]['url'];out={'engine':engine,'image':state[engine]['image'],'cases':[],'plans':[]}
    for tc in suite['cases']:
        i=tc['input']
        if engine=='opa':
            code,raw=request(base+'/v1/data/ontology/allow',{'input':i})
            allowed=raw.get('result',False)
        else:
            attr={**i['resource'],**{k:v for k,v in i.items() if k not in ['subject','resource','operation']}}
            body={'principal':principal(i['subject']),'resources':[{'resource':{'id':attr['id'],'kind':'equipment','attr':attr},'actions':[i['operation']]}]}
            code,raw=request(base+'/api/check/resources',body)
            allowed=raw.get('results',[{}])[0].get('actions',{}).get(i['operation'])=='EFFECT_ALLOW'
        out['cases'].append({'name':tc['name'],'expected':tc['expected'],'allowed':allowed,'pass':code==200 and allowed==tc['expected'],'status':code,'response':raw})
    for operation in ['read','read_price','unknown_operation']:
        if engine=='opa':
            body={'input':{'subject':suite['principal'],'operation':operation},'unknowns':['input.resource']}
            for target in ['ucast.all','sql.mysql','sql.postgresql']:
                code,raw=request(base+'/v1/compile/ontology/allow',body,{'Accept':'application/vnd.opa.'+target+'+json'})
                out['plans'].append({'operation':operation,'target':target,'status':code,'response':raw})
            classic={**body,'query':'data.ontology.allow = true'}
            code,raw=request(base+'/v1/compile',classic)
            out['plans'].append({'operation':operation,'target':'classic_rego_ast','status':code,'response':raw})
        else:
            body={'principal':principal(suite['principal']),'resource':{'kind':'equipment'},'actions':['read',operation] if operation=='read_price' else [operation]}
            code,raw=request(base+'/api/plan/resources',body)
            out['plans'].append({'operation':operation,'target':'cerbos_ast','status':code,'response':raw})
    (ROOT/'evidence'/(engine+'-checks.json')).write_text(json.dumps(out,indent=2))
    print(json.dumps({'engine':engine,'cases':len(out['cases']),'passed':sum(x['pass'] for x in out['cases']),'failed':[x for x in out['cases'] if not x['pass']],'plans':out['plans']},indent=2))
