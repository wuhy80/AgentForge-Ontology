package ontology

import rego.v1

default allow := false

has_role(role) if role in input.subject.roles

valid if {
    input.subject.tenant == input.resource.tenant
    input.resource.blocked == false
}

own if {
    input.subject.department == input.resource.department
    input.resource.line in input.subject.lines
}

row_allowed if has_role("catalog")
row_allowed if { has_role("finance"); input.subject.department == input.resource.department }
row_allowed if { has_role("maintainer"); own }

allow if { input.operation in {"read", "read_name"}; valid; row_allowed }
allow if {
    input.operation == "read_price"
    valid
    has_role("finance")
    not has_role("contractor")
    input.subject.department == input.resource.department
}
allow if {
    input.operation == "action_invoke"
    valid
    has_role("maintainer")
    own
    input.reason in {"repair", "inspect"}
}
allow if {
    input.operation == "function_invoke"
    valid
    has_role("maintainer")
    own
    input.via_action == "maintenance"
}
allow if {
    input.operation == "patch_status"
    valid
    has_role("maintainer")
    own
    input.resource.status == "stopped"
    input.new_status == "running"
    input.new_department == input.subject.department
}
