import subprocess,os,json,time,uuid,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DOCKER=r'D:\Programs\Docker\Docker\resources\bin\docker.exe'
os.environ['PATH']=str(Path(DOCKER).parent)+os.pathsep+os.environ['PATH']
state_file=ROOT/'containers.json'
state=json.loads(state_file.read_text()) if state_file.exists() else {}
images={'opa':'openpolicyagent/opa:1.21.2-static','cerbos':'ghcr.io/cerbos/cerbos:0.56.0','openfga':'openfga/openfga:v1.22.0','spicedb':'ghcr.io/authzed/spicedb:v1.56.2'}
ports={'opa':8181,'cerbos':3592,'openfga':8080,'spicedb':8443}
arguments={
 'opa':['run','--server','--addr=0.0.0.0:8181','--log-level=error','/policies/ontology.rego'],
 'cerbos':['server','--config=/config/cerbos.yaml'],
 'openfga':['run','--datastore-engine=memory','--playground-enabled=false','--log-level=error'],
 'spicedb':['serve','--datastore-engine=memory','--grpc-preshared-key=ontology-temporary-evaluation','--http-enabled=true','--http-addr=:8443','--log-level=error'],
}
for engine in sys.argv[1:]:
 if engine in state:
  print(json.dumps({'engine':engine,'existing':state[engine]}));continue
 name='ontology-auth-eval-'+engine+'-'+uuid.uuid4().hex[:8]
 args=[DOCKER,'run','-d','--name',name,'--label','ontology.auth-eval=true','--cpus=1','--memory=256m','-p',f'127.0.0.1::{ports[engine]}']
 if engine=='opa':args+=['--mount',f'type=bind,source={ROOT / "ontology.rego"},target=/policies/ontology.rego,readonly']
 if engine=='cerbos':args+=['--mount',f'type=bind,source={ROOT / "policies"},target=/policies,readonly','--mount',f'type=bind,source={ROOT / "cerbos.yaml"},target=/config/cerbos.yaml,readonly']
 p=subprocess.run(args+[images[engine]]+arguments[engine],capture_output=True,text=True)
 if p.returncode:print(json.dumps({'engine':engine,'error':p.stderr}));continue
 cid=p.stdout.strip();state[engine]={'id':cid,'name':name,'image':images[engine]};state_file.write_text(json.dumps(state,indent=2))
 details=json.loads(subprocess.check_output([DOCKER,'inspect',cid],text=True))[0]
 bound=details['NetworkSettings']['Ports'].get(str(ports[engine])+'/tcp')
 if bound:state[engine]['url']='http://127.0.0.1:'+bound[0]['HostPort']
 state[engine]['image_id']=details['Image'];state_file.write_text(json.dumps(state,indent=2))
 print(json.dumps({'engine':engine,**state[engine]}))
