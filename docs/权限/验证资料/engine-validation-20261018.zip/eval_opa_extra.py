from pathlib import Path
import json,urllib.request,urllib.error
ROOT=Path(__file__).resolve().parent
suite=json.loads((ROOT/'cases.json').read_text())
state=json.loads((ROOT/'containers.json').read_text())
base=state['opa']['url'];history=[];checks=[]
def req(path,body,headers=None,method=None):
    payload=body.encode() if isinstance(body,str) else json.dumps(body).encode()
    r=urllib.request.Request(base+path,payload,headers={'Content-Type':'application/json',**(headers or {})},method=method)
    try:
        with urllib.request.urlopen(r,timeout=12) as f:
            raw=f.read().decode();code=f.status;value=json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:code=e.code;value=json.loads(e.read())
    history.append({'path':path,'method':method or 'POST','status':code,'response':value})
    return code,value
policy='''package experiments
import rego.v1

# METADATA
# scope: document
# compile:
#   unknowns: [input.resource]
#   mask_rule: data.experiments.masks
filter if data.ontology.allow

masks := {"resource": {"price": {"replace": {"value": "***"}}}} if "contractor" in input.subject.roles

default live_allow := false
live_allow if { data.authz.active[input.subject.id] == true; data.ontology.allow }

default unsupported := false
unsupported if { crypto.sha256(input.resource.department) == "d1" }

default explicit_not := false
explicit_not if { input.resource.tenant == input.subject.tenant; not input.resource.blocked }
'''
code,raw=req('/v1/policies/experiments',policy,{'Content-Type':'text/plain'},'PUT');assert code==200,(code,raw)
i=suite['cases'][0]['input']
contractor={**i,'subject':{**i['subject'],'roles':['catalog','contractor']}}
code,raw=req('/v1/compile/experiments/filter',{'input':{k:v for k,v in contractor.items() if k!='resource'},'unknowns':['input.resource']},{'Accept':'application/vnd.opa.ucast.all+json'})
masks=raw.get('result',{}).get('masks',{})
checks.append({'name':'static-column-mask-compilation','pass':code==200 and masks.get('resource',{}).get('price',{}).get('replace',{}).get('value')=='***','response':raw})
for active in [True,False,True]:
    code,raw=req('/v1/data/authz',{'active':{'alice':active}},method='PUT');assert code==204,(code,raw)
    c,r=req('/v1/data/experiments/live_allow',{'input':i})
    checks.append({'name':'live-membership-'+str(active),'pass':c==200 and r.get('result')==active,'response':r})
code,raw=req('/v1/compile/experiments/unsupported',{'input':{},'unknowns':['input.resource']},{'Accept':'application/vnd.opa.ucast.all+json'})
checks.append({'name':'unsupported-builtin-compilation','pass':code>=400,'status':code,'response':raw})
for target in ['sql.dameng','sql.mysql']:
    code,raw=req('/v1/compile/ontology/allow',{'input':{'subject':suite['principal'],'operation':'read_price'},'unknowns':['input.resource']},{'Accept':'application/vnd.opa.'+target+'+json'})
    checks.append({'name':'dialect-'+target,'pass':code>=400 if target=='sql.dameng' else code==200,'status':code,'response':raw})
missing={**i,'subject':{k:v for k,v in i['subject'].items() if k!='department'},'operation':'read_price'}
code,raw=req('/v1/data/ontology/allow',{'input':missing});checks.append({'name':'missing-subject-attribute','pass':code==200 and raw.get('result')==False,'response':raw})
injection={**i,'subject':{**i['subject'],'department':"d1' OR 1=1 --"},'operation':'read_price'}
code,raw=req('/v1/compile/ontology/allow',{'input':{k:v for k,v in injection.items() if k!='resource'},'unknowns':['input.resource']},{'Accept':'application/vnd.opa.sql.mysql+json'})
checks.append({'name':'sql-literal-escaping-observation','status':code,'response':raw,'observation':'MySQL target uses backslash escaping; do not use SQL text as parameterized query or assume sql_mode compatibility.'})
code,raw=req('/v1/compile/ontology/allow',{'input':{k:v for k,v in injection.items() if k!='resource'},'unknowns':['input.resource']},{'Accept':'application/vnd.opa.ucast.all+json'})
query=raw.get('result',{}).get('query',{})
checks.append({'name':'ucast-injection-value-remains-data','status':code,'response':raw,'pass':code==200 and any(x.get('value')=="d1' OR 1=1 --" for x in query.get('value',[]))})
out={'engine':'OPA 1.21.2','checks':checks,'history':history}
(ROOT/'evidence/opa-extra.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
